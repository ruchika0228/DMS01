// content.js
window.addEventListener("message", (event) => {
  // SECURITY: Only accept messages from the current window
  if (event.source !== window) return;

  // We look for messages starting with "FROM_PAGE_..."
  if (event.data.type && event.data.type.startsWith("FROM_PAGE_")) {
    console.log("Extension received command:", event.data.command);

    // Forward to Background Worker
    chrome.runtime.sendMessage(event.data, (response) => {
      
      // CHECK FOR CHROME RUNTIME ERRORS (The missing piece!)
      if (chrome.runtime.lastError) {
        console.error("Extension Connection Error:", chrome.runtime.lastError);
        response = { success: false, error: "Extension Connection Failed: " + chrome.runtime.lastError.message };
      }
      
      // Fallback if response is completely undefined
      if (!response) {
        response = { success: false, error: "Unknown Background Error (Response was empty)" };
      }

      // Send response back to Page
      window.postMessage({
        type: "FROM_IPFS_TO_PAGE",
        command: event.data.command,
        requestId: event.data.requestId, // Echo ID
        payload: response
      }, "*");
    });
  }
});