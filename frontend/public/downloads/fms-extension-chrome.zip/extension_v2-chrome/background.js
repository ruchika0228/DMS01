// background.js

// Listen for messages from content.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background received command:", message.command);

  // 1. Handle UPLOAD_FILE
  if (message.command === "UPLOAD_FILE") {
    // We call the async function, and handle the response via .then()/.catch()
    uploadToIpfs(message.fileData, message.fileName)
      .then((response) => {
        console.log("Upload success:", response);
        sendResponse(response);
      })
      .catch((error) => {
        console.error("Upload failed:", error);
        sendResponse({ success: false, error: error.message });
      });
      
    return true; // CRITICAL: Keeps the message channel open for the async response
  }

  // 2. Handle PIN_FILE
  if (message.command === "PIN_FILE") {
    pinToIpfs(message.cid)
      .then((response) => {
        console.log("Pin success:", response);
        sendResponse(response);
      })
      .catch((error) => {
        console.error("Pin failed:", error);
        sendResponse({ success: false, error: error.message });
      });

    return true; // CRITICAL: Keeps the message channel open for the async response
  }

  // Optional: Log unknown commands
  console.warn("Unknown command received:", message.command);
  return false; // Close channel immediately for unknown commands
});


// --- HELPER FUNCTIONS ---

// Function to Upload File to Local IPFS Node
async function uploadToIpfs(base64Data, fileName) {
  try {
    // 1. Decode Base64 back to Blob
    // We expect base64Data to look like "data:application/pdf;base64,JVBERi..."
    const base64Content = base64Data.split(',')[1] || base64Data;
    const byteCharacters = atob(base64Content);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray]);

    const formData = new FormData();
    formData.append("file", blob, fileName);

    // 2. Call IPFS API (Port 5001 is standard for API)
    const response = await fetch("http://127.0.0.1:5001/api/v0/add", {
      method: "POST",
      body: formData
    });

    if (!response.ok) {
        throw new Error(`IPFS Upload Error: ${response.statusText}`);
    }

    const data = await response.json();
    return { success: true, cid: data.Hash };

  } catch (error) {
    console.error("Error in uploadToIpfs:", error);
    throw error; // Throwing here sends it to the .catch() block in the listener
  }
}

// Function to Pin File on Local IPFS Node
async function pinToIpfs(cid) {
  try {
    // Call IPFS Pin API
    const response = await fetch(`http://127.0.0.1:5001/api/v0/pin/add?arg=${cid}`, {
      method: "POST"
    });

    if (!response.ok) {
        throw new Error(`IPFS Pin Error: ${response.statusText}`);
    }

    const data = await response.json();
    // IPFS Pin API usually returns { Pins: ["Qm..."] }
    return { success: true, pinned_cid: data.Pins ? data.Pins[0] : cid };

  } catch (error) {
    console.error("Error in pinToIpfs:", error);
    throw error; // Throwing here sends it to the .catch() block in the listener
  }
}